package com.example.bubblesortapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Spliterator;

import androidx.appcompat.app.AppCompatActivity;

import android.util.Log;

import com.google.android.material.textfield.TextInputLayout;



public class MainActivity extends AppCompatActivity {
    private static final String TAG = "In loop";

    EditText inputNumbers;
    ListView sortedOutput;
    ArrayList<String> array;
    ArrayAdapter<String> adapter;
    Integer[] indNumbers;
    String[] finalArray;
    TextInputLayout orderSorting;
    AutoCompleteTextView optionsSorting;

    ArrayList<String> order_Sort;
    ArrayAdapter<String> arrayAdapter_sort;


    Button clearBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        inputNumbers = findViewById(R.id.inputNum);
        sortedOutput = findViewById(R.id.outputNum);
        array = new ArrayList<String>();

        orderSorting = (TextInputLayout)findViewById(R.id.orderSorting);
        optionsSorting = (AutoCompleteTextView)findViewById(R.id.optionsSorting);

        order_Sort= new ArrayList<>();
        order_Sort.add("Ascending");
        order_Sort.add("Descending");

        arrayAdapter_sort = new ArrayAdapter<>(getApplicationContext(),R.layout.support_simple_spinner_dropdown_item,order_Sort);
        optionsSorting.setAdapter(arrayAdapter_sort);

        optionsSorting.setThreshold(1);

        sortedOutput.setAdapter(adapter);


        clearBtn = findViewById(R.id.clearBtn);
        clearBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                inputNumbers.getText().clear();
                array.clear();
                sortedOutput.invalidateViews();

            }
        });
    }

    public void onCLick(View view) {
        String[] inputList = inputNumbers.getText().toString().split(",");
        array.clear();
        sortedOutput.invalidateViews();
        indNumbers = new Integer[inputList.length];

        for (int i = 0; i < inputList.length; i++) {
            indNumbers[i] = Integer.parseInt(inputList[i]);
        }
        if(String.valueOf(optionsSorting.getText()).equals("Ascending")) {
            bubbleSortAscend(indNumbers, indNumbers.length);
        }
        else {
            bubbleSortDescend(indNumbers, indNumbers.length);
        }

    }

    public void bubbleSortAscend(Integer[] indNumbers, int length) {


        if (length < 2) {
            return;
        }
        int n = length;
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (indNumbers[j] > indNumbers[j + 1]) {
                    // swap arr[j+1] and arr[j]
                    int temp = indNumbers[j];
                    indNumbers[j] = indNumbers[j + 1];
                    indNumbers[j + 1] = temp;
                }
            }
            array.add("Iteration " +i +" : "+ Arrays.toString(indNumbers));
            finalArray = array.get((array.size())-1).toString().split(",");
        }
        String[] output = array.get(array.size() - 1).split(":");
        array.remove(array.size()-1);
        array.add("Output: "+output[1]);
        adapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_list_item_1,array);
        sortedOutput.setAdapter(adapter);

    }


    public void bubbleSortDescend(Integer[] indNumbers, int length) {


        if (length < 2) {
            return;
        }
        int n = length;
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (indNumbers[j] < indNumbers[j + 1]) {
                    // swap arr[j+1] and arr[j]
                    int temp = indNumbers[j];
                    indNumbers[j] = indNumbers[j + 1];
                    indNumbers[j + 1] = temp;
                }
            }
            array.add("Iteration " +i +" : "+ Arrays.toString(indNumbers));

            finalArray = array.get((array.size())-1).toString().split(",");
        }
        String[] output = array.get(array.size() - 1).split(":");
        array.remove(array.size()-1);
        array.add("Output: "+output[1]);
        adapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_list_item_1,array);
        sortedOutput.setAdapter(adapter);
    }
}



