package com.example.bubblesortapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import java.util.Arrays;

public class MainActivity extends AppCompatActivity {

    EditText inputNumbers;
    EditText sortedOutput;

    Button clearBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        inputNumbers = findViewById(R.id.inputNum);
        sortedOutput = findViewById(R.id.outputNum);

        clearBtn = findViewById(R.id.clearBtn);
        clearBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                inputNumbers.getText().clear();
            }
        });
    }

    public void onCLick(View view){
        String[] inputList = inputNumbers.getText().toString().split(",");
        Integer[] indNumbers = new Integer[inputList.length];

        for(int i =0;i<inputList.length; i++){
            indNumbers[i] = Integer.parseInt(inputList[i]);
        }

        bubbleSort(indNumbers, indNumbers.length);
        sortedOutput.setText(Arrays.toString(indNumbers));
    }

    private void bubbleSort(Integer[] indNumbers, int length){
        if(length<2){
            return;
        }

        for(int i=0; i<length-1; i++){
            if(indNumbers[i]>indNumbers[i+1]){
                Integer temp = indNumbers[i];
                indNumbers[i] = indNumbers[i+1];
                indNumbers[i+1] = temp;
            }

        }

        /* For descending
        for(int i=0; i<length-1; i++){
            if(indNumbers[i]<indNumbers[i+1]){
                Integer temp = indNumbers[i];
                indNumbers[i] = indNumbers[i+1];
                indNumbers[i+1] = temp;
            }

        }

         */

        bubbleSort(indNumbers,length-1);
    }
}